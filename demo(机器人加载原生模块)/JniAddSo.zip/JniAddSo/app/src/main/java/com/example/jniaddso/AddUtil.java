package com.example.jniaddso;

public class AddUtil {

    static {
        System.loadLibrary("addLib");//so库名,最终库名为lib+你起的库名（addLib）
    }
    //必须加native
    public static native int add(int addend, int summand);

}
