#include <jni.h>

#include "com_example_jniaddso_AddUtil.h"

JNIEXPORT jint JNICALL Java_com_example_jniaddso_AddUtil_add
  (JNIEnv *env, jobject obj, jint addend, jint summand){
    return add(addend, summand);
  }

  int add(int addend, int summand){
    return addend + summand;
  }