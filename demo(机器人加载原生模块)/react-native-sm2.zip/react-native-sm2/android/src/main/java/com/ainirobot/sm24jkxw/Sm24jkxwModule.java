package com.ainirobot.sm24jkxw;

import javax.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapRegionDecoder;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import com.example.jniaddso.AddUtil;
import com.facebook.common.logging.FLog;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.GuardedAsyncTask;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.JSApplicationIllegalArgumentException;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.infer.annotation.Assertions;
import com.facebook.react.common.ReactConstants;

import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.engines.SM2Engine;

/**
 * Native module that provides image cropping functionality.
 */
public class Sm24jkxwModule extends ReactContextBaseJavaModule {

    protected static final String NAME = "Sm24jkxw";
    protected static final String TAG = "Sm24jkxwModule";

    public Sm24jkxwModule(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @ReactMethod
    public void encrypt(String data, String publicKey,
                        Callback errorCallback, Callback successCallback) {
        Log.d(TAG, "encrypt:" + data);
        try {
            String resStr = Sm2V1Util.encrypt(data, publicKey, SM2Engine.Mode.C1C2C3);
            successCallback.invoke(resStr);
        } catch (Exception e) {
            errorCallback.invoke(e.getMessage());
        }
    }

    @ReactMethod
    public void decrypt(String data, String privateKey,
                        Callback errorCallback, Callback successCallback) {
        Log.d(TAG, "decrypt:" + data);
        try {
            String resStr = Sm2V1Util.decrypt(data, privateKey, SM2Engine.Mode.C1C2C3);
            successCallback.invoke(resStr);
        } catch (Exception e) {
            errorCallback.invoke(e.getMessage());
        }
    }

    @ReactMethod
    public void addSum(int addend, int summand,
                    Callback errorCallback, Callback successCallback) {
        Log.d(TAG, "addSumAddend:" + addend);

        try {
            int i = AddUtil.add(addend, summand);
            successCallback.invoke(i);
            Log.d(TAG, "addSum:" + i);
        } catch (Exception e) {
            errorCallback.invoke(e.getMessage());
        }
    }

    @ReactMethod
    public void generateSm2KeyPair(Callback errorCallback, Callback successCallback) {
        Log.d(TAG, "generateSm2KeyPair:");
        try {
            KeyPair resStr = Sm2V1Util.generateSm2KeyPair();
            successCallback.invoke(resStr.getPrivate().toString(), resStr.getPublic().toString());
        } catch (Exception e) {
            errorCallback.invoke(e.getMessage());
        }
    }
}
