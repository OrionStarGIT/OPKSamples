package com.example.jniaddso;

public class AddUtil {

    static {
        System.loadLibrary("addLib");
    }

    public static native int add(int addend, int summand);

}
